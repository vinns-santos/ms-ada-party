package br.com.ada.party.model;

public enum PartyType {
    CLIENTE, FUNCIONARIO, FORNECEDOR
}
