package br.com.ada.party.exception;

public class InvalidTypeException extends Exception{
}
