package br.com.ada.party.model;

public enum FinancialDocumentTypeValues {
    RG, CPF, CNPJ
}
